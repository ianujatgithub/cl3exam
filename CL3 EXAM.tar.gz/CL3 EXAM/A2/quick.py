import xml.etree.ElementTree as et
import threading
import unittest
	

class TestClass(unittest.TestCase):
	def test1(self):
		self.assertEqual(ReadFile("input.xml"),True)

	def test2(self):
		self.assertEqual(ReadFile("input1.xml"),False)
	
	def test3(self):
		obj1=Sort([9,7,-45,0,23,2,34,65])
		self.assertEqual(obj1.partition(0,7),4)

	def test4(self):
		obj1=Sort([9,7,-45,0,23,2,34,65])
		self.assertEqual(obj1.Quick(0,7),[-45,0,2,7,9,23,34,65])


class Sort:
	arr=[]
	def __init__(self,arr):
		self.arr=arr

	def partition(self,low,high):
		pivot=self.arr[low]
		i=low
		j=high
		while(i<j):
			while(self.arr[i]<=pivot and i<j):
				i+=1
			while(self.arr[j]>pivot and i<=j):
				j-=1
			if(i<=j):
				self.arr[i],self.arr[j]=self.arr[j],self.arr[i]
		self.arr[low],self.arr[j]=self.arr[j],self.arr[low]
		return j
		

	def Quick(self,low,high):
		if(low<high):
			index=self.partition(low,high)
			thread1=threading.Thread(target=self.Quick,args=(low,index-1))
			thread2=threading.Thread(target=self.Quick,args=(index+1,high))
			thread1.start()
			thread2.start()
			thread1.join()
			print("Thread running is %s : "%thread1.getName())
			thread2.join()
			print("Thread running is %s : "%thread2.getName())
		return self.arr
	
def ReadFile(filename):
	try:
		name=filename.split(".")
		if(name[1]=="xml"):
			tree=et.parse(filename)
			root=tree.getroot()
			array=list(map(int,root.text.split()))
			
			obj=Sort(array)
			print obj.arr
			obj.Quick(0,len(obj.arr)-1)
			print(obj.arr)
			return True

	except Exception as e:
		print e	
	return False


if __name__ == '__main__':
	ReadFile("input.xml")

unittest.main()
