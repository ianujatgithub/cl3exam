import xml.etree.ElementTree as et
import threading



def ReadFile(filename):
	try:
		name=filename.split('.')
		if(name[1]=='xml'):
			tree=et.parse(filename)
			root=tree.getroot()
			data=list(map(int,root.text.split()))
			print data
	except Exception as e:
		print e


def main():
	filename=raw_input("Enter Name of File:")
	ReadFile(filename)

main()
	

