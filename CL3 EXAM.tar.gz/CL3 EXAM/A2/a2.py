import threading
import xml.etree.ElementTree as et
import unittest

class TestClass(unittest.TestCase):
	def test_Func_1(self):
		self.assertEqual(func("input.xml"),True)
	
	
	
def func(filename):
	try:
		name=filename.split(".")
		if(name[1]=='xml'):
			tree=et.parse(filename)
			root=tree.getroot()
			a=list(map(int,root.text.split()))
			return True
	except Exception as e:
		print(e)
	return False

if __name__ == '__main__':
	func("input.xml")
unittest.main()
