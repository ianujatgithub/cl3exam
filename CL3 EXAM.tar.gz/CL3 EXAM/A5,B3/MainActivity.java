package com.example.nikitakagade.cal_final;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import net.objecthunter.exp4j.Expression;
import net.objecthunter.exp4j.ExpressionBuilder;

public class MainActivity extends AppCompatActivity {
    private Button button[]=new Button[10];
    private TextView res1,res2;
    Button add,sub,equ,clr,mems,memr,sin,cos,memc;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;
    public static  final String mypreferences="Mypref";
    public static final String Key="Key";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sharedPreferences=getSharedPreferences(mypreferences, Context.MODE_PRIVATE);
        editor=sharedPreferences.edit();

        setButtons();
        setOnclicklistners();
    }

    public void setButtons()
    {
        button[0]=findViewById(R.id.button);
        button[1]=findViewById(R.id.button2);
        button[2]=findViewById(R.id.button3);

        add=findViewById(R.id.button4);
        sub=findViewById(R.id.button5);
        equ=findViewById((R.id.button7));

        res1=findViewById(R.id.textView);
        res2=findViewById(R.id.textView2);

        clr=findViewById(R.id.clear);
        sin=findViewById(R.id.sin);
        cos=findViewById(R.id.cos);
        memr=findViewById(R.id.memr);
        mems=findViewById(R.id.mems);
        memc=findViewById(R.id.memc);
    }
    private void setOnclicklistners()
    {
        View.OnClickListener temp=new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text=((Button) view).getText().toString();
                res1.append(text);
            }
        };


        for(int i=0;i<3;++i)
        {
            button[i].setOnClickListener(temp);
        }

        add.setOnClickListener(temp);
        sub.setOnClickListener(temp);
        sin.setOnClickListener(temp);

        equ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onEqual();
            }
        });

        clr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                res1.setText(" ");
                res2.setText(" ");
            }
        });

        sin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String prev=res1.getText().toString().trim();
                if(!prev.isEmpty())
                {
                    double rad=Math.toRadians(Double.valueOf(prev));
                    double ans=Math.sin(rad);
                    String ans1=String.valueOf(ans);
                    res2.setText(ans1);
                    res1.setText(" ");
                }
            }
        });
        memc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(sharedPreferences.getAll().containsKey(Key))
                {
                    Toast.makeText(getApplicationContext(),"Memory cleared",Toast.LENGTH_SHORT).show();
                    editor.remove(Key);
                    editor.commit();
                }
            }
        });
        mems.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text=res2.getText().toString();
                if(text!="")
                {
                    Toast.makeText(getApplicationContext(),text+"is stored in memory.",Toast.LENGTH_SHORT).show();
                    editor.putString(Key,text);
                    editor.commit();

                }else
                {
                    Toast.makeText(getApplicationContext(), "Output is empty",Toast.LENGTH_SHORT).show();
                }

            }
        });
        memr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(sharedPreferences.getAll().containsKey(Key))
                {
                    res2.append(sharedPreferences.getString(Key,""));

                }
                else
                {
                    Toast.makeText(getApplicationContext(),"their is no data,",Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private void onEqual()
    {
        try {

            String ans=res1.getText().toString();
            Expression expression=new ExpressionBuilder(ans).build();
            double result=expression.evaluate();
            res2.setText(String.format("%.12f",result));

        }catch(Exception e)
        {
            res2.setText("Error");
        }
    }


}
