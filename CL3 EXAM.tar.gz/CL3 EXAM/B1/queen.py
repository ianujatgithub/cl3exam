import json
import unittest
size=8

class Queen:
	def issafe(self,row,col):
		for r in range(size):
			for c in range(size):
				if(board[r][c]==1):
					if(r==row or c==col or abs(r-row)==abs(c-col)):
						return False
		return True
			

	def solve(self,row):
	
		if(row==size):
			self.printboard(board)
			return True
	
		for col in range(size):
			if(self.issafe(row,col)):
				board[row][col]=1
				if(self.solve(row+1)):
					return True
				else:
					board[row][col]=0
				

	def printboard(self,board):
		for i in range (size):
			for j in range (size):
				print board[i][j]," ",
			print("")
		print("")

board = []
def main():
	file=open("input.json",'r+')
	data=json.loads(file.read())

	for i in range(size):
		vv=[0]*size
		board.append(vv)

	board[0][data['start']]=1
	obj=Queen()
	obj.solve(1)
	

main()

