from flask import Flask
from flask import render_template
from flask import request

app= Flask(__name__)

bits=16
length=2*bits+1

@app.route('/')
def index():
	return render_template('booths.html')

@app.route('/evaluate',methods=['POST','GET'])
def index1():
	num1=int(request.form['input1'])
	num2=int(request.form['input2'])
	result=str(booths(num1,num2))
	return render_template('booths.html',result=result)	

def AddBinary(num1,num2):
	c=0
	result=[]
	for i in range(length):
		result.append(0)
	i=length-1
	while i>=0:
		temp=num1[i]+num2[i]+c
		result[i]=temp%2
		c=temp/2
		i-=1
	return result

def Two_complement(num):
	one=[]
	ans=[]
	for i in range(length):
		one.append(0)
		ans.append(0)

	one[length-2]=1
	for i in range(length):
		if(num[i]==0):
			ans[i]=1
		else:
			ans[i]=0
	res=AddBinary(ans,one)
	return res
		
	
def BinaryToDecimal(num):
	sign=num[0]
	result=0
	if sign==1:
		print "here u go"
		num=Two_complement(num)
	
	i=length-2
	j=0
	while i>=0:
		result+=num[i]*(pow(2,j))
		i-=1
		j+=1

	if sign==1:
		return (-result)
	else:
		return result
		

def DecimalToBinary(num):
	a=[]
	for i in range(bits):
		a.append(0)
	i=bits-1
	while i>=0 and num!=0:
		a[i]=num%2
		num=int(num/2)
		i-=1
	return a

def RightShift(num):
	i=length-1
	while i>0:
		num[i]=num[i-1]
		i-=1
	return num


def booths(num1,num2):
	A=[0 for i in range(bits)]
	Q=[]
	M=[]
	N=[]
	
	M=DecimalToBinary(num1)
	Q=DecimalToBinary(num2)
	N=DecimalToBinary(-num1)
	
	for i in range(length-bits):
		M.append(0)
		N.append(0)

	A=A+Q
	A.append(0)
	print(Two_complement(M))
	print N
	for i in range(bits):
		if ((A[-2]==0 and A[-1]==0)or(A[-2]==1 and A[-1]==1)):
			A=RightShift(A)
			print("First condition",A)
			
		
		elif(A[-2]==0 and A[-1]==1):
			A=AddBinary(A,M)
			
			A=RightShift(A)
			print("Second condition",A)
	
		elif(A[-2]==1 and A[-1]==0):
			A=AddBinary(A,N)
			A=RightShift(A)
			print("Third condition",A)

	answer=BinaryToDecimal(A)

	return answer
		
	

if __name__=='__main__':
	app.run(debug=True)


