from pymongo import MongoClient
import random
import time
import threading


class Philosopher(threading.Thread):
	running=True
	counter=0
	connection=MongoClient("localhost",27017)

	@staticmethod
	def ReadFromShared(self,index):
		print("%s Reading Raw data"%self.Name)
		db=Philosopher.connection.test.rawdata
		limit=self.counter
		cursor=db.find({"ph_no":index})[limit:limit+1]
		print (cursor[0])
		self.counter+=1
		self.counter%=9
	
	def __init__(self,index,name,left,right):
		threading.Thread.__init__(self)
		self.index=index
		self.Name=name
		self.LeftFork=left
		self.RightFork=right
	
	def run(self):
		while(self.running):
			time.sleep(random.uniform(3,13))
			print("%s is Hungry"%self.Name)
			
			self.dine()
		
	def dine(self):
		fork1,fork2=self.LeftFork,self.RightFork
		while(self.running):
			fork1.acquire(True)
			locked= fork2.acquire(False)
			if(locked): break
		
			fork1.release()
			print("%s swapped the forks"%self.Name)
			fork1,fork2=fork2,fork1
		else:
			return
			
		self.dining()
		fork1.release()
		fork2.release()

	def dining(self):
		while(self.running):
			print("%s Starts Eating"%self.Name)
			self.ReadFromShared(self,self.index)
			time.sleep(random.uniform(1,10))
			print("%s Finished Eating"%self.Name)
			
			

def DiningPhilosopher():
	forks=[threading.Lock() for i in range(5)]
	PhilosopherNames=['Niki','Yash','vaibhav','Teju','Uttu']
	philosophers=[Philosopher(i,PhilosopherNames[i],forks[i%5],forks[(i+1)%5]) for i in range(5)]
	
	random.seed(5555)
	Philosopher.running=True
	for i in philosophers: i.start()
	time.sleep(100)
	Philosopher.running=False
		
	



DiningPhilosopher()
