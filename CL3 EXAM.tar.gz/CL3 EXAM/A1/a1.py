import unittest
import threading
import time

class MyTest(unittest.TestCase):

	def setUp(self):
		self.binary_2=Search([11,12,13,14,15])
	def test0(self):
		self.assertEqual(self.binary_2.bsearch(12,0,4),1)
	def test1(self):
		self.assertEqual(self.binary_2.bsearch_recurssion(12,0,4),1)
				

class Search:
	arr=[]
	
	def __init__(self,a):
		self.arr=a

	def bsearch(self,num,low,high):
		mid=int((low+high)/2)
		while(low<=high):
			mid=int((low+high)/2)
			if(self.arr[mid]==int(num)):
				return mid
			elif(num<self.arr[mid]):
				high=mid-1
			else:
				low=mid+1
		return -1

	def bsearch_recurssion(self,num,low,high):
		mid=int((low+high)/2)
		if(low>high):
			return -1
		if(self.arr[mid]==int(num)):
			return mid
		elif(num<self.arr[mid]):
			high=mid-1
		else:
			low=mid+1
		return self.bsearch_recurssion(num,low,high)
	
	def partition(self,low,high):
		pivot=self.arr[low]
		i=low
		j=high
		while(i<j):
			while(self.arr[i]<=pivot and i<j):
				i+=1
			while(self.arr[j]>pivot and i<=j):
				j-=1
			if(i<=j):
				self.arr[i],self.arr[j]=self.arr[j],self.arr[i]

		self.arr[low],self.arr[j]=self.arr[j],self.arr[low]
		return j
				
	
	def Quick(self,low,high):
		if(low<high):
			index=self.partition(low,high)
			thread1=threading.Thread(target=self.Quick,args=(low,index-1))
			thread2=threading.Thread(target=self.Quick,args=(index+1,high))
			thread1.start()
			thread2.start()
			thread1.join()
			print("Thread Running is:",thread1.getName())
			thread2.join()
			print("Thread Running is:",thread2.getName())
	
	def Linear(self,num):
		for i in range(len(self.arr)-1):
			print(i)
			if(self.arr[i]==num):
				print(i)
				return i
		return -1
		
		
				

def getFile(filename):
	file=open(filename,'r+')
	arr=[]
	res=0
	for line in file:
		arr.append(int(line.strip()))
	obj=Search(arr)
	print(obj.arr)
	
	print(obj.arr)
	ch=input("Enter Choice\n1.Binary Search without recurssion\n2.Binary Search with recurssion\n3.linear search")
	number=input("Enter Number")
	if ch==1:
		start_time=time.time()
		obj.Quick(0,len(arr)-1)
		res=obj.bsearch(number,0,len(arr)-1)
		print("Time required for w/o recurssion is %.6f "%(time.time()-start_time))

	if ch==2:
		start_time=time.time()
		obj.Quick(0,len(arr)-1)
		res=obj.bsearch_recurssion(number,0,len(arr)-1)
		print("Time required for recurssion is %.6f "%(time.time()-start_time))

	if ch==3:
		start_time=time.time()
		res=obj.Linear(number)
		print("Time required for linear search is %.6f "%(time.time()-start_time))

	if res<0:
		print("Not Found")
	else:
		print("Number found at position %d"%res)
		
		
def main():
	filename=raw_input("Enter Name of File\n")
	getFile(filename)

main()
unittest.main()

