from pymongo import MongoClient
from datetime import datetime

connection=MongoClient("localhost",27017)

db=connection.test.rawdata



def LoadData(filename):
	file=open(filename,'r+').read().strip().split("\n")
	data=[]
	for line in file:
		result=line.strip().split(',')
		print(result)
		result=[int(e) for e in result]
		post={"ph_no":result[0],"Time":datetime.now(),"Temp":result[1]}
		db.insert_one(post)
		
			

LoadData("rawdata.txt")

