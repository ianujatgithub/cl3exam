from flask import Flask
from flask import render_template
from flask import request

app = Flask(__name__)

txt1="this is sohail"

def lcs (text1,text2) :
	lcs_set=set([])	
	S = text1
	T = text2
	sWords = S.split(' ')
	dWords = T.split(' ')
	m = len(sWords)
	n = len(dWords)
	
	#counter=[[0]*(n+1) for x in range(m+1)]
	#print(counter)
	longest=0
	for i in range(m):
		for j in range(n):
			if sWords[i] == dWords[j]:
				lcs_set.add(sWords[i])
	return lcs_set
	

@app.route('/')
def index():
	return render_template('index.html')
	

@app.route('/data', methods=['POST'])
def ff():
	txt2=request.form['tx1']
	ret=lcs(txt1,txt2)	
	print(ret)
	ln=len(ret)
	val=float(ln)/len(txt1.split(' ')) * 100
	return "Plagiarism percentage:"+str(val)	
	
if __name__ == '__main__':
	app.run(debug=True,host='0.0.0.0',port=8080)
	
