from flask import Flask
from flask import render_template
from flask import request

app=Flask(__name__)

text1=[]
text2=[]
text3=[]

file1=open("text1.txt","r")
for line in file1:
	text1.append(line.strip())


file2=open("text2.txt","r")
for line in file2:
	text2.append(line.strip())


file3=open("text3.txt","r")
for line in file3:
	text3.append(line.strip())


def calculate(input):

	return result
		

@app.route('/')
def index():
	return render_template('index.html')

@app.route('/check',methods=['POST','GET'])
def display():
	if(request.method=='POST'):
		input=request.form['input']
		print(input.strip())
		copy=0
		text4=[]

		database=[text1,text2,text3]

		lines=input.split('\n')
		length=len(lines)


		
		for file in database:
			for line in lines:
				if (line.strip()) in file:
					copy+=1

		result=float(copy/length)*100
		
		per=str(result)
		print(copy)
		print(length)
		return render_template('index.html',result=per)
	else:
		return render_template('index.html')


if __name__=='__main__':
	app.run()






