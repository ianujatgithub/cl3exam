package com.example.uttkarsha.shubham;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import net.objecthunter.exp4j.Expression;
import net.objecthunter.exp4j.ExpressionBuilder;

public class MainActivity extends AppCompatActivity {

    Button button[]=new Button[10];
    Button add,sub,mul,div,sin,mems,memr,memc,equal,clear;
    TextView input,output;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    private static final String mypref="MyPref";
    private static final String key="Key";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sharedPreferences=getSharedPreferences(mypref,MODE_PRIVATE);
        editor=sharedPreferences.edit();

        setbuttons();
        setonclicklistener();
    }
    private void setbuttons()
    {
        button[0]=(Button)findViewById(R.id.button);
        button[1]=(Button)findViewById(R.id.button2);
        button[2]=(Button)findViewById(R.id.button3);
        button[3]=(Button)findViewById(R.id.button4);
        button[4]=(Button)findViewById(R.id.button5);
        button[5]=(Button)findViewById(R.id.button6);
        button[6]=(Button)findViewById(R.id.button7);
        button[7]=(Button)findViewById(R.id.button8);
        button[8]=(Button)findViewById(R.id.button9);
        button[9]=(Button)findViewById(R.id.button10);

        clear=(Button)findViewById(R.id.button11);
        equal=(Button)findViewById(R.id.button12);

        add=(Button)findViewById(R.id.button13);
        sub=(Button)findViewById(R.id.button14);
        mul=(Button)findViewById(R.id.button15);
        div=(Button)findViewById(R.id.button16);

        sin=(Button)findViewById(R.id.button17);
        mems=(Button)findViewById(R.id.button18);
        memr=(Button)findViewById(R.id.button19);
        memc=(Button)findViewById(R.id.button20);

        input=(TextView)findViewById(R.id.textView);
        output=(TextView)findViewById(R.id.textView2);
    }

    private void setonclicklistener()
    {
        View.OnClickListener temp=new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s=((Button)view).getText().toString();
                input.append(s);
            }
        };

        for(int i=0;i<10;i++)
        {
            button[i].setOnClickListener(temp);
        }

        add.setOnClickListener(temp);
        sub.setOnClickListener(temp);
        mul.setOnClickListener(temp);
        div.setOnClickListener(temp);

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                input.setText("");
                output.setText("");
            }
        });

        equal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s=input.getText().toString();
                Expression expression=new ExpressionBuilder(s).build();
                double result=expression.evaluate();
                output.setText(String.valueOf(result));
            }
        });

        sin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s=input.getText().toString();
                double result=Math.sin(Double.valueOf(s));
                output.setText(String.valueOf(result));
            }
        });

        mems.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s=output.getText().toString();
                editor.putString(key,s);
                editor.commit();
                Toast.makeText(getApplicationContext(),s+" is saved into memory",Toast.LENGTH_SHORT).show();
            }
        });

        memr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(sharedPreferences.getAll().containsKey(key))
                {
                    input.append(sharedPreferences.getString(key,""));
                }
            }
        });

        memc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(sharedPreferences.getAll().containsKey(key))
                {
                    editor.remove(key);
                    editor.commit();
                }
            }
        });
    }
}
